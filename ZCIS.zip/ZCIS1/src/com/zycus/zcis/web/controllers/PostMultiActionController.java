package com.zycus.zcis.web.controllers;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.zcis.common.api.CategoryServiceAPI;
import com.zycus.zcis.common.api.LoginServiceApi;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.CategoryEditor;

@Controller
@RequestMapping(value="/posts")
@SessionAttributes("user")
public class PostMultiActionController
{

	@Autowired
	private PostServiceAPI postServiceAPI; 
	
	@Autowired
	private CategoryServiceAPI categoryServiceAPI;
	
	private @Autowired
	CategoryEditor categoryEditor;
	
	@Autowired
	private LoginServiceApi loginServiceApi;
	
	public PostServiceAPI getPostServiceAPI() {
		return postServiceAPI;
	}


	public void setPostServiceAPI(PostServiceAPI postServiceAPI) {
		this.postServiceAPI = postServiceAPI;
	}


	public CategoryServiceAPI getCategoryServiceAPI() {
		return categoryServiceAPI;
	}


	public void setCategoryServiceAPI(CategoryServiceAPI categoryServiceAPI) {
		this.categoryServiceAPI = categoryServiceAPI;
	}


	public CategoryEditor getCategoryEditor() {
		return categoryEditor;
	}


	public void setCategoryEditor(CategoryEditor categoryEditor) {
		this.categoryEditor = categoryEditor;
	}


	@InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(Category.class, this.categoryEditor);
    }

	
	@RequestMapping(value = "/goToCreatePostPage", method = RequestMethod.GET)
	public String goToCreatePostPage(ModelMap model)
	{
		Post newPost = new Post();
		
		ZcisUser user = (ZcisUser)model.get("user");
		newPost.setPostedByUser(user);
		List<Category> categoryList =categoryServiceAPI.getCategoryList(true); 
		model.addAttribute("categoryList",categoryList );
		model.addAttribute("newPost",newPost);
		return "newPost";
	}
	
	@RequestMapping(value = "/createNewPost")
	public String createNewPost(@ModelAttribute(value="newPost") @Valid Post newPost,BindingResult result,@ModelAttribute("user")ZcisUser user, Model model)
	{
		
		if(newPost==null)
		{
			List<Category> categoryList =categoryServiceAPI.getCategoryList(true); 
			model.addAttribute("categoryList",categoryList );
			return "newPost";
		}
		
		if(result.hasErrors())
		{
			List<Category> categoryList =categoryServiceAPI.getCategoryList(true); 
			model.addAttribute("categoryList",categoryList );
			return "newPost";
		}
		
		
		newPost.setPostedByUser(user);
		postServiceAPI.savePost(newPost);
		newPost.setFollowingUserSet(new HashSet<ZcisUser>());
		model.addAttribute("post", newPost);
		return "viewPost";
	}
	
	@RequestMapping(value = "/showPostDashboard")
	public String showPostDashboard(Model model)
	{
		List<Post> postList = postServiceAPI.getAllPost(false);
		for(Post post:postList)
		{
			post.setNoOfComments(postServiceAPI.getCommentsCount(post.getPostId()));
		}
		model.addAttribute("postList",postList);
		return "postsDashboard";
	}
	
	@RequestMapping(value = "/viewPost", method = RequestMethod.GET)
	   public String viewPost(ModelMap model,@RequestParam String postId) 
	{
		long postIdLong = Long.parseLong(postId);
	      Post  post = postServiceAPI.getPostById(postIdLong,false);
	      if(model.get("user")!=null)
	    	  loginServiceApi.disableNotificationForPost(post.getPostId());	      
	      List<Comments>  comments = null;
	      if(post!=null)
	      {
	    	  comments = postServiceAPI.getAllCommentsByPostID(post.getPostId(),false);
	    	  model.addAttribute("post",post);
	    	  if(comments!=null)
	    		  model.addAttribute("comments", comments);
	      }
	      
	      return "viewPost";
	   }

	@RequestMapping(value = "/getPostsByCategory",method = RequestMethod.GET)
	public String getPostsByCategory(Model model , @RequestParam String categoryId)
	{
		long categoryIdLong = Long.parseLong(categoryId);
		Category category = categoryServiceAPI.getCategoryById(categoryIdLong,false);

		model.addAttribute("postList",category.getPostSet());
		model.addAttribute("categoryName",category.getCategoryName());
		return "postsDashboard";
	}
	
	@RequestMapping(value = "/search",method = RequestMethod.POST)
	public String search(@RequestParam String searchText,Model model)
	{
		Set<Post> postSet = postServiceAPI.searchPostsByText(searchText);
		model.addAttribute("postList",postSet);
		model.addAttribute("searchText",searchText);
		return "postsDashboard";
	}
}
