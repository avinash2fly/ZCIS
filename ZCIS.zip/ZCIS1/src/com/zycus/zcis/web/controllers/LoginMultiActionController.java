package com.zycus.zcis.web.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.owlike.genson.stream.JsonWriter;
import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.SessionListener;


@Controller
@RequestMapping(value="/lmac")
@SessionAttributes("user")
public class LoginMultiActionController {

	
	
	
}
