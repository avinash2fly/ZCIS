package com.zycus.zcis.web.controllers;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.zcis.common.util.SessionListener;

@Controller
@RequestMapping("/alc")
public class AjaxLogOutController {

	
	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	   public void logoutUser(ModelMap model, HttpServletResponse response,HttpSession session) throws JSONException, IOException {
		JSONObject jsonObject = new JSONObject();  
		try
	      {
	    	  //model.addAttribute("user", null);
	    	  //model.clear();
	    	  session.invalidate();
	    	  jsonObject.put("success", true);
	    	  //SessionListener.destroySession(session);	     
	      }
	      catch(Exception e)
	      {
	    	  jsonObject.put("success", false);
	      }
	      
	      
	      
	      response.getWriter().write(jsonObject.toString());
	   }
}
