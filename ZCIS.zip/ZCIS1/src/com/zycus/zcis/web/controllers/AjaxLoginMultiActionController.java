package com.zycus.zcis.web.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.ad.client.LoginClient;
import com.zycus.ad.entities.ZyUser;
import com.zycus.ad.exceptions.AuthenticationException;
import com.zycus.zcis.common.api.LoginServiceApi;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.LoginUser;
import com.zycus.zcis.common.bo.UserNotification;
import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.SessionListener;
import com.zycus.zcis.web.filter.AuthorizationFilter;


@Controller
@RequestMapping(value="/almac")
@SessionAttributes("user")
public class AjaxLoginMultiActionController {
	public static final Log logger=LogFactory.getLog(AjaxLoginMultiActionController.class);
	
	
	@Autowired
	private LoginServiceApi loginServiceApi; 
	
	/**
	 * @return the loginServiceApi
	 */
	public LoginServiceApi getLoginServiceApi() {
		return loginServiceApi;
	}

	/**
	 * @param loginServiceApi the loginServiceApi to set
	 */
	public void setLoginServiceApi(LoginServiceApi loginServiceApi) {
		this.loginServiceApi = loginServiceApi;
	}

	@RequestMapping(value = "/loginForm")
	public String showLoginPage(ModelMap model)
	{
		LoginUser loginUser =  new LoginUser();
		
		model.addAttribute("loginUser", loginUser);
		
		return "common/loginForm";
	}
	
	@RequestMapping(value = "/performLogin", method = RequestMethod.POST)
	public String performLogin(@ModelAttribute(value="loginUser") @Valid LoginUser loginUser,BindingResult result, Model model)
	{
		if(!model.containsAttribute("user"))
		{
			if(loginUser==null)
			{
				return "common/loginForm";
			}
			
			if(result.hasErrors())
			{
				return "common/loginForm";
			}
			
			LoginClient client = new LoginClient();
			ZyUser user=null;
			ZcisUser zcisUser = new ZcisUser();
			try {
				user = client.authenticateUser(loginUser.getUserName(), loginUser.getPassword());
				if(user.getIsAuthenticated())
				{
					zcisUser.setEmailId(loginUser.getUserName()+"@zycus.com");
					zcisUser.setDisplayName(loginUser.getUserName());
					zcisUser = loginServiceApi.saveOrUpdateZcuisUser(zcisUser);
					
					model.addAttribute("user", zcisUser);
				}
				else
				{
					return "common/loginForm";
				}
			} catch (AuthenticationException e) {
				logger.error("Error while Authenticating User :  ", e);
			}
			
		}
		
		String redirectUrl = "/almac/successLogin.do";
        return "redirect:" + redirectUrl;
		
	}
	
	@RequestMapping(value = "/successLogin")
	public void successLogin(Model model,HttpServletResponse response) throws IOException
	{
		response.getWriter().write("");
	}
	
	
	@RequestMapping(value="/showNotification",  method=RequestMethod.POST)
	public String showNotification(ModelMap model) throws Exception
	{
		ZcisUser user = (ZcisUser)model.get("user");
		List<UserNotification> notificationsList =  loginServiceApi.getNotificationByUserId(user.getUserid(),false);
		model.addAttribute("notifications",notificationsList);
		return "common/notificationList";
	}
	
	@RequestMapping(value="/getNotificationCount",  method=RequestMethod.POST)
	public void getNotificationCount(ModelMap model,HttpServletResponse response) throws Exception
	{
		ZcisUser user = (ZcisUser)model.get("user");
		JSONObject jsonObject = new JSONObject();
		if(user!=null)
		{
			List<UserNotification> notificationsList =  loginServiceApi.getNotificationByUserId(user.getUserid(),true);
			jsonObject.put("success", true);
			jsonObject.put("count", notificationsList.size());
		}
		else
		{
			jsonObject.put("success", true);
		}
				
		
		
		
		response.getWriter().write(jsonObject.toString());
	}
	
}
