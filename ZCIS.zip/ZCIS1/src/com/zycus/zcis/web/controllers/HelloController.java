/**
 * 
 */
package com.zycus.zcis.web.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.zcis.application.service.HelloService;
import com.zycus.zcis.common.api.HelloServiceApi;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;



/**
 * @author avinash.gupta
 *
 */
@Controller
@RequestMapping(value="/cm")

@SessionAttributes("user")
public class HelloController{
	
	@Autowired
	private HelloServiceApi helloServiceApi;

	@Autowired
    private PostServiceAPI postServiceAPI;

	
    
   /**
	 * @return the helloServiceApi
	 */
	public HelloServiceApi getHelloServiceApi() {
		return helloServiceApi;
	}




	/**
	 * @param helloServiceApi the helloServiceApi to set
	 */
	public void setHelloServiceApi(HelloServiceApi helloServiceApi) {
		this.helloServiceApi = helloServiceApi;
	}




@RequestMapping(value = "/hello", method = RequestMethod.GET)
   public String printHello(ModelMap model) {
      model.addAttribute("message", "Hello Spring MVC amogh1!");
     
      List<Post>  posts = postServiceAPI.getAllPost(false);
      
      List<Comments>  comments = null;
      if(posts!=null)
      {
    	  comments = postServiceAPI.getAllCommentsByPostID(posts.get(0).getPostId(),false);
    	  model.addAttribute("post",posts.get(0));
    	  if(comments!=null)
    		  model.addAttribute("comments", comments);
      }
      /*List<ZcisUser> users= helloServiceApi.getUser();
      model.addAttribute("user",users.get(0));*/
      
      return "viewPost";
   }

}
