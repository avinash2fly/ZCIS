package com.zycus.zcis.web.controllers;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.zcis.common.api.CategoryServiceAPI;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.ZcisUser;

@Controller
@RequestMapping(value="/acmac")
@SessionAttributes("user")
public class AjaxCommonMultiActionController 
{
	@Autowired
	private CategoryServiceAPI categoryServiceAPI;

	public CategoryServiceAPI getCategoryServiceAPI() {
		return categoryServiceAPI;
	}

	public void setCategoryServiceAPI(CategoryServiceAPI categoryServiceAPI) {
		this.categoryServiceAPI = categoryServiceAPI;
	}
	
	@Autowired
	private PostServiceAPI postServiceAPI;
	
	
		
	public PostServiceAPI getPostServiceAPI() {
		return postServiceAPI;
	}

	public void setPostServiceAPI(PostServiceAPI postServiceAPI) {
		this.postServiceAPI = postServiceAPI;
	}

	@RequestMapping(value ="/getCategoryList", method = RequestMethod.GET)
	public String getCategoryList(Model model )
	{
		List<Category> categoryList = categoryServiceAPI.getCategoryList(false);
		model.addAttribute("ajaxCategoryList",categoryList);
		 return "categoryList";
	}

	
	@RequestMapping(value ="/createNewCategory", method = RequestMethod.GET)
	public void createNewCategory(HttpServletResponse response,@RequestParam String categoryname) throws IOException, JSONException
	{
		boolean isCreated = categoryServiceAPI.createNewCategory(categoryname);
		
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("success",isCreated);
			response.getWriter().write(jsonObject.toString());
		 
	}
	
	@RequestMapping(value="/followOrUnfollowPost")
	public void followOrUnfollowPost(@RequestParam String postId,Model model,@ModelAttribute("user")ZcisUser user,HttpServletResponse response) throws Exception
	{
		long postIdLong = Long.parseLong(postId);
		
		Map<String, Object> followingMap = postServiceAPI.followOrUnfollowPost(postIdLong,user);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("following",(Boolean)followingMap.get("isFollowing"));
		jsonObject.put("noOfFollowers",(Integer)followingMap.get("noOfFollowers"));
		response.getWriter().write(jsonObject.toString());
	}
	
	
}
