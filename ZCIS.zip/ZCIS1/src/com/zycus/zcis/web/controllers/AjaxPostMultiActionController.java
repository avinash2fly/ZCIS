package com.zycus.zcis.web.controllers;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.json.JSONArray;
import org.json.JSONWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.zcis.common.api.CategoryServiceAPI;
import com.zycus.zcis.common.api.LoginServiceApi;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.CategoryEditor;

@Controller
@RequestMapping(value="/aPost")
@SessionAttributes("user")
public class AjaxPostMultiActionController
{

	@Autowired
	private PostServiceAPI postServiceAPI; 
	
	@Autowired
	private CategoryServiceAPI categoryServiceAPI;
	
	@Autowired
	private LoginServiceApi loginServiceApi;
	
	/**
	 * @return the postServiceAPI
	 */
	public PostServiceAPI getPostServiceAPI() {
		return postServiceAPI;
	}

	/**
	 * @param postServiceAPI the postServiceAPI to set
	 */
	public void setPostServiceAPI(PostServiceAPI postServiceAPI) {
		this.postServiceAPI = postServiceAPI;
	}

	/**
	 * @return the categoryServiceAPI
	 */
	public CategoryServiceAPI getCategoryServiceAPI() {
		return categoryServiceAPI;
	}

	/**
	 * @param categoryServiceAPI the categoryServiceAPI to set
	 */
	public void setCategoryServiceAPI(CategoryServiceAPI categoryServiceAPI) {
		this.categoryServiceAPI = categoryServiceAPI;
	}

	@RequestMapping(value = "/postComment.do")
	public String postComment(ModelMap model,HttpServletRequest request,@RequestParam String postId,@RequestParam String commentText)
	{
		ZcisUser user = (ZcisUser)model.get("user");
		String commentValue = commentText;
		long  postIdLong = Long.parseLong(postId);
		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		Post post = postServiceAPI.getPostById(postIdLong, false);
		if (ipAddress == null)
		{
			ipAddress = request.getRemoteAddr();
		}
		
		Comments Comment = null;
		if(user!=null)
		{	
			Comment =  new Comments();
			Comment.setCommentText(commentValue);
			Comment.setCommentedBy(user);
			Comment.setPost(post);
			Comment.setIpAddress(ipAddress);
			postServiceAPI.persistComment(Comment);
			loginServiceApi.notifyUserForPost(post);
		}
		List<Comments> comments = postServiceAPI.getAllCommentsByPostID(postIdLong, false);
		model.addAttribute("comments", comments);
		
		return "post/commentList";
	}
	
	
	
}
