package com.zycus.zcis.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.ThreadLocalConstant;

public class AuthorizationFilter implements Filter {


	public static final Log logger=LogFactory.getLog(AuthorizationFilter.class);
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
			FilterChain chain) throws IOException, ServletException {
		
		
		
	  HttpServletRequest request=(HttpServletRequest)servletRequest;
	  HttpServletResponse response = (HttpServletResponse)servletResponse;
	  HttpSession session = request.getSession();
	  String requestURL="";
	  /*if(session.getAttribute("user")==null)
	  {
		  SessionListener.destroySession(session);
	  }*/
	  
	  ZcisUser user = (ZcisUser) session.getAttribute("user");
	  boolean isAjaxCall=false;
	  
	  if ("XMLHttpRequest".equals(((HttpServletRequest) request).getHeader("X-Requested-With")))
		{
			isAjaxCall = true;
		}
	  
	  if(user!=null)
	  {
		  ThreadLocalConstant.UserThreadLocal.set(user);
		  
	  }
	  else
	  {	 
			  ThreadLocalConstant.UserThreadLocal.remove();
			  if(checkRequestURL(requestURL))
			  {
				  response.sendRedirect(request.getContextPath());
			  }
		
	  }
	
	  chain.doFilter(servletRequest, servletResponse);
	  

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
	}

	private Boolean checkRequestURL(String requestURL)
	{
		if(	
				(requestURL.contains("/posts/createNewPost.do")
						||requestURL.contains("/aPost/postComment.do")
						||requestURL.contains("/acmac/createNewCategory.do")
				)
			)
		{
			return true;
		}
		
		return false;
		
	}
}
