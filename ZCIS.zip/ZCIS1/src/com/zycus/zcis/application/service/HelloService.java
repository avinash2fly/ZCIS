package com.zycus.zcis.application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.zcis.application.dao.HelloDao;
import com.zycus.zcis.common.api.HelloServiceApi;
import com.zycus.zcis.common.bo.ZcisUser;

@Service
public class HelloService  implements HelloServiceApi
{

	@Autowired
    private HelloDao helloDao;
    	
   
	
	/**
	 * @return the helloDao
	 */
	public HelloDao getHelloDao() {
		return helloDao;
	}



	/**
	 * @param helloDao the helloDao to set
	 */
	public void setHelloDao(HelloDao helloDao) {
		this.helloDao = helloDao;
	}



	@Transactional
	@Override
	public List<ZcisUser> getUser() 
	{
		 @SuppressWarnings("unchecked")
		List<ZcisUser> userlist= helloDao.getUser();
		return userlist;
	}
	

}
