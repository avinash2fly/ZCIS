package com.zycus.zcis.application.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.zcis.common.api.CommonDaoAPI;
import com.zycus.zcis.common.api.LoginDaoApi;
import com.zycus.zcis.common.api.LoginServiceApi;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.UserNotification;
import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.ThreadLocalConstant;

@Service
public class LoginServiceImpl implements LoginServiceApi {

	@Autowired
	private LoginDaoApi loginDaoApi;
	
	@Autowired
	private CommonDaoAPI commonDaoAPI;

	/**
	 * @return the loginDaoApi
	 */
	public LoginDaoApi getLoginDaoApi() {
		return loginDaoApi;
	}

	/**
	 * @param loginDaoApi the loginDaoApi to set
	 */
	public void setLoginDaoApi(LoginDaoApi loginDaoApi) {
		this.loginDaoApi = loginDaoApi;
	}

	/**
	 * @return the commonDaoAPI
	 */
	public CommonDaoAPI getCommonDaoAPI() {
		return commonDaoAPI;
	}

	/**
	 * @param commonDaoAPI the commonDaoAPI to set
	 */
	public void setCommonDaoAPI(CommonDaoAPI commonDaoAPI) {
		this.commonDaoAPI = commonDaoAPI;
	}

	@Override
	@Transactional
	public ZcisUser saveOrUpdateZcuisUser(ZcisUser zcisUser) {
		// TODO Auto-generated method stub
		ZcisUser tempZcisUser = commonDaoAPI.getUserByEmail(zcisUser.getEmailId());
		if(tempZcisUser==null)
		{
			commonDaoAPI.persistObject(zcisUser);
			return zcisUser; 
		}
		else
			return tempZcisUser;
		
	}

	@Transactional
	@Override
	public void notifyUserForPost(Post post) {
		// TODO Auto-generated method stub
		
		Set<ZcisUser> zcisUsers  = post.getFollowingUserSet();
		zcisUsers.add(post.getPostedByUser());
		ZcisUser loggedInUSer = (ZcisUser)ThreadLocalConstant.UserThreadLocal.get();
		zcisUsers.remove(loggedInUSer);
		List<UserNotification> notificationList = new ArrayList<UserNotification>();
		for(ZcisUser user :zcisUsers)
		{
			UserNotification notification = new UserNotification();
			if(user.getUserid()==post.getPostedByUser().getUserid())
				notification.setNotificationText(loggedInUSer.getDisplayName()+" has commented on your post");
			else
				notification.setNotificationText(loggedInUSer.getDisplayName()+" has commented on post you're following");
			notification.setPost(post);
			notification.setUser(user);
			notificationList.add(notification);
		}
		
		loginDaoApi.saveNotificationList(notificationList);
	}

	@Transactional
	@Override
	public List<UserNotification> getNotificationByUserId(long userid,boolean isLazy) {
		// TODO Auto-generated method stub
		List<UserNotification> notifications = null;
		
		notifications = loginDaoApi.getNotificationByUserId(userid);
		if(!isLazy)
		{
			for(UserNotification notification : notifications)
			{
				notification.getPost().getPostId();
			}
		}
			
		return notifications;
	}

	@Override
	@Transactional
	public void disableNotificationForPost(long postId) {
		// TODO Auto-generated method stub
		if(ThreadLocalConstant.UserThreadLocal.get()!=null)
		{
			List<UserNotification> notifications = loginDaoApi.getNotificationByPostid(postId);
			for(UserNotification notification : notifications)
			{
				notification.setViewed(true);
				loginDaoApi.saveNotification(notification);
			}
		}
		
	}
	
	
	
	
	
	

}
