package com.zycus.zcis.application.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.zcis.common.api.CategoryDaoAPI;
import com.zycus.zcis.common.api.CategoryServiceAPI;
import com.zycus.zcis.common.api.PostDaoAPI;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;
@Service
public class CategoryServiceImpl implements CategoryServiceAPI 
{
	@Autowired
	CategoryDaoAPI categoryDaoAPI;
	

	public CategoryDaoAPI getCategoryDaoAPI() {
		return categoryDaoAPI;
	}


	public void setCategoryDaoAPI(CategoryDaoAPI categoryDaoAPI) {
		this.categoryDaoAPI = categoryDaoAPI;
	}
	
	@Autowired
	private PostDaoAPI postDaoAPI;

	public PostDaoAPI getPostDaoAPI() {
		return postDaoAPI;
	}


	public void setPostDaoAPI(PostDaoAPI postDaoAPI) {
		this.postDaoAPI = postDaoAPI;
	}


	@Transactional
	@Override
	public List<Category> getCategoryList(boolean isLazy) {
		
		return categoryDaoAPI.getCategoryList(isLazy);
	}

	@Transactional
	@Override
	public Category getCategoryById(Long categoryId,boolean isLazy) 
	{
		Category category = categoryDaoAPI.getCategoryById(categoryId);
		if(category!=null)		
			if(!isLazy)
				{
					Set<Post> postSet = category.getPostSet();
					for(Post post : postSet)
					{
						Set<Category> categorySet = post.getCategorySet();
						for(Category cat : categorySet)
						{
							cat.getCategoryId();
							cat.getCategoryName();
						}
						post.getFollowingUserSet();
						
						Set<ZcisUser> followingUserSet = post.getFollowingUserSet();
						for(ZcisUser zcisUser : followingUserSet)
						{
							zcisUser.getUserid();
						}
						post.setNoOfComments(postDaoAPI.getCommentsCount(post.getPostId()));
						post.getPostedByUser().getDisplayName();
					}
				}
		return category;
	}

	@Transactional
	@Override
	public boolean createNewCategory(String categoryname) 
	{
		
		Category category = categoryDaoAPI.getCategoryByName(categoryname);
		if(category!=null)
		{
			return false;
		}
		else
			{
			category = new Category();
			category.setCategoryName(categoryname);
			categoryDaoAPI.createCategory(category);
			return true;
			}
	
	}

}
