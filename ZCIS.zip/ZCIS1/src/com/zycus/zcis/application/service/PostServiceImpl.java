package com.zycus.zcis.application.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.zcis.common.api.CommonDaoAPI;
import com.zycus.zcis.common.api.PostDaoAPI;
import com.zycus.zcis.common.api.PostServiceAPI;
import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;

@Service
public class PostServiceImpl implements PostServiceAPI {

	@Autowired
	private PostDaoAPI postDaoApi;

	@Autowired
	private CommonDaoAPI commonDaoApi;
	
	public PostDaoAPI getPostDaoApi() {
		return postDaoApi;
	}


	public void setPostDaoApi(PostDaoAPI postDaoApi) {
		this.postDaoApi = postDaoApi;
	}


	public CommonDaoAPI getCommonDaoApi() {
		return commonDaoApi;
	}


	public void setCommonDaoApi(CommonDaoAPI commonDaoApi) {
		this.commonDaoApi = commonDaoApi;
	}

	@Transactional
	@Override
	public void savePost(Post newPost) {
		commonDaoApi.persistObject(newPost);
		
	}

	@Transactional
	@Override
	public List<Post> getAllPost(boolean isLazy) {
		// TODO Auto-generated method stub
		List<Post> posts = postDaoApi.getAllPost();
		if(!isLazy)
		{
			for(Post post : posts)
			{
				for(Category category : post.getCategorySet())
				{
					category.getCategoryName();
					category.getCategoryId();
				}
				post.getPostedByUser().getDisplayName();
				post.getPostedByUser().getUserid();
				
				post.getFollowingUserSet().size();
			}
			
			
			
		}
		
		return posts;
		
		
	
	}


	@Transactional
	@Override
	public List<Comments> getAllCommentsByPostID(long postId,boolean isLazy) {
		// TODO Auto-generated method stub
		List<Comments> commentsList = postDaoApi.getAllCommentsbyPostID(postId);
		
		if(!isLazy)
		{
			for(Comments comment : commentsList)
			{
				comment.getCommentedBy();
			}
		}
		
		return commentsList;
	}

	@Transactional
	@Override
	public void persistComment(Comments comments) {
		// TODO Auto-generated method stub
				postDaoApi.saveComment(comments);
		
	}
	

	@Transactional
	@Override
	public Map<String, Object> followOrUnfollowPost(long postId, ZcisUser user) 
	{
		Post post = this.getPostById(postId,false);
		Set<ZcisUser> followingUserSet = post.getFollowingUserSet();
		boolean isFollowing = followingUserSet.contains(user);
		if(isFollowing)
			followingUserSet.remove(user);
		else 
			followingUserSet.add(user);
		commonDaoApi.persistObject(post);
		Map<String, Object> followerMap = new HashMap<>();
		followerMap.put("isFollowing", !isFollowing);
		followerMap.put("noOfFollowers", followingUserSet.size());
		return followerMap;
	}


	@Transactional
	@Override
	public long getCommentsCount(long postId) 
	{

		return postDaoApi.getCommentsCount(postId);
	}

	@Transactional
	@Override
	public Post getPostById(long postId, boolean isLazy) 
	{
		Post post = postDaoApi.getPostById(postId);
		if(post!=null)
		{
			if(!isLazy)
			{
				Set<Category> categorySet = post.getCategorySet();
				for(Category cat : categorySet)
				{
					cat.getCategoryId();
					cat.getCategoryName();
				}
				Set<ZcisUser> followingUserSet = post.getFollowingUserSet();
				for(ZcisUser zcisUser : followingUserSet)
				{
					zcisUser.getUserid();
					zcisUser.getDisplayName();
				}

				post.getPostedByUser().getUserid();
				post.getPostedByUser().getDisplayName();
				
			}
		}
		return post;
	}


	@Transactional
	@Override
	public Set<Post> searchPostsByText(String searchText) 
	{
		Set<Post> postSet = new HashSet<>();
		List<Post> postListByTitle = postDaoApi.getAllPostsByTitle(searchText);
		List<Post> postListByDesc = postDaoApi.getAllPostsByDesc(searchText);
		Set<Post> postListByCategory = postDaoApi.getAllPostsByCategory(searchText);
		
		postSet.addAll(postListByTitle);
		postSet.addAll(postListByDesc);
		postSet.addAll(postListByCategory);
		for(Post post : postSet)
		{
			if(post!=null)
			{
				
					Set<Category> categorySet = post.getCategorySet();
					for(Category cat : categorySet)
					{
						cat.getCategoryId();
						cat.getCategoryName();
					}
					Set<ZcisUser> followingUserSet = post.getFollowingUserSet();
					for(ZcisUser zcisUser : followingUserSet)
					{
						zcisUser.getUserid();
						zcisUser.getDisplayName();
					}

					post.getPostedByUser().getUserid();
					post.getPostedByUser().getDisplayName();
					post.setNoOfComments(this.getCommentsCount(post.getPostId()));
			}
		}
		
		return postSet;
	}

}
