package com.zycus.zcis.application.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.zycus.zcis.common.api.CommonDaoAPI;
import com.zycus.zcis.common.bo.ZcisUser;
@Repository
public class CommonDaoImpl implements CommonDaoAPI {

	@Autowired(required=true)
	@Qualifier(value="hibernate4AnnotatedSessionFactory")
	private SessionFactory sessionFactory;
    
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public void persistObject(Object obj) 
	{
	
		this.sessionFactory.getCurrentSession().saveOrUpdate(obj);

	}

	@Override
	public ZcisUser getUserByEmail(String emailId) {
		// TODO Auto-generated method stub
		
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(ZcisUser.class);
		criteria.add(Restrictions.eq("emailId", emailId).ignoreCase());
		ZcisUser zcisUser = (ZcisUser)criteria.uniqueResult();
		return zcisUser;
	}

}
