package com.zycus.zcis.application.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.zycus.zcis.common.api.PostDaoAPI;
import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;

@Repository
public class PostDaoImpl implements PostDaoAPI 
{

	@Autowired(required=true)
	@Qualifier(value="hibernate4AnnotatedSessionFactory")
	private SessionFactory sessionFactory;
    
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Post> getAllPost() {
		// TODO Auto-generated method stub
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(Post.class);
		//criteria.add(Restrictions.ne("status", 4));
		criteria.addOrder(Order.desc("createdOn"));		
		List<Post>  posts = (List<Post>)criteria.list();
		return posts;
	}

	@Override
	public List<Comments> getAllCommentsbyPostID(long postId) {
		// TODO Auto-generated method stub
		
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(Comments.class);
		criteria.createAlias("post", "postAlias");
		criteria.add(Restrictions.eq("postAlias.postId", postId));
		criteria.addOrder(Order.asc("commentedOn"));
		List<Comments> commentsList = (List<Comments>)criteria.list();
		return commentsList;
	}

	@Override
	public void saveComment(Comments comments) {
		// TODO Auto-generated method stub
		this.sessionFactory.getCurrentSession().save(comments);
	}
	
	
	@Override
	public Post getPostById(long postId) 
	{
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(Post.class);
		criteria.add(Restrictions.eq("postId", postId));
		Object post = criteria.uniqueResult();
		if(post!=null)
			return (Post)post;
		else
			return null;
	}

	@Override
	public long getCommentsCount(long postId) 
	{
		Criteria commentsCriteria = this.sessionFactory.getCurrentSession().createCriteria(Comments.class);
		commentsCriteria.createAlias("post", "postAlias");
		commentsCriteria.add(Restrictions.eq("postAlias.postId", postId));
		commentsCriteria.setProjection(Projections.rowCount());
		return (Long)commentsCriteria.uniqueResult();
	}

	@Override
	public List<Post> getAllPostsByTitle(String searchText) 
	{
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(Post.class);
		//criteria.add(Restrictions.ne("status", 4));
		criteria.add(Restrictions.ilike("title", searchText,MatchMode.ANYWHERE));
		List<Post>  posts = (List<Post>)criteria.list();
		return posts;
	}

	@Override
	public List<Post> getAllPostsByDesc(String searchText) 
	{
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(Post.class);
		//criteria.add(Restrictions.ne("status", 4));
		criteria.add(Restrictions.ilike("description", searchText,MatchMode.ANYWHERE));
		List<Post>  posts = (List<Post>)criteria.list();
		return posts;
	}

	@Override
	public Set<Post> getAllPostsByCategory(String searchText) 
	{
		Criteria categoryNameCriteria = this.sessionFactory.getCurrentSession().createCriteria(Category.class);
		//categoryNameCriteria.createAlias("postSet", "postAlias");
		//categoryNameCriteria.add(Restrictions.ne("postAlias.status", 4));
		categoryNameCriteria.add(Restrictions.ilike("categoryName", searchText,MatchMode.ANYWHERE));
		categoryNameCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<Category> categoryList = categoryNameCriteria.list();
		if(categoryList!=null)
		{
			Set<Post> postSet = new HashSet<>();
			for(Category category : categoryList)
			{
				postSet.addAll(category.getPostSet());
			}
			return postSet;
		}
		else
			return new HashSet<>();
	}

	

}
