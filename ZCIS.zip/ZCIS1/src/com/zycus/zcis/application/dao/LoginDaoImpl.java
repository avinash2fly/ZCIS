package com.zycus.zcis.application.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.zycus.zcis.common.api.LoginDaoApi;
import com.zycus.zcis.common.bo.UserNotification;
import com.zycus.zcis.common.bo.ZcisUser;
import com.zycus.zcis.common.util.ThreadLocalConstant;

@Repository
public class LoginDaoImpl implements LoginDaoApi{

	
	@Autowired(required=true)
	@Qualifier(value="hibernate4AnnotatedSessionFactory")
	private SessionFactory sessionFactory;
    
    public void setSessionFactory(SessionFactory sessionFactory){
        this.sessionFactory = sessionFactory;
    }

	@Override
	public void saveNotificationList(List<UserNotification> notificationList) {
		// TODO Auto-generated method stub
		
		Session session = this.sessionFactory.getCurrentSession();
		for(int i=0;i<notificationList.size();i++)
		{
			this.saveNotification(notificationList.get(i));
			if ( i % 100 == 0 ) {
		        session.flush();
		        session.clear();
		    }
			
		}
	}

	@Override
	public void saveNotification(UserNotification notification) {
		// TODO Auto-generated method stub
		this.sessionFactory.getCurrentSession().saveOrUpdate(notification);
	}

	@Override
	public List<UserNotification> getNotificationByUserId(long userid) {
		// TODO Auto-generated method stub
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(UserNotification.class);
		criteria.createAlias("user", "userAlias");
		criteria.add(Restrictions.eq("userAlias.userid", userid));
		criteria.add(Restrictions.eq("isViewed", Boolean.valueOf(false)));
		criteria.addOrder(Order.desc("date"));
		return criteria.list();
	}

	@Override
	public List<UserNotification> getNotificationByPostid(long postId) {
		// TODO Auto-generated method stub
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(UserNotification.class);
		criteria.createAlias("post", "postAlias");
		criteria.add(Restrictions.eq("postAlias.postId", postId));
		criteria.createAlias("user", "userAlias");
		criteria.add(Restrictions.eq("userAlias.userid", ((ZcisUser)ThreadLocalConstant.UserThreadLocal.get()).getUserid()));
		criteria.add(Restrictions.eq("isViewed", Boolean.valueOf(false)));
		criteria.addOrder(Order.desc("date"));
		return criteria.list();
		
	}
	
}
