package com.zycus.zcis.application.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.zycus.zcis.common.bo.ZcisUser;

@Repository
public class HelloDao 
{	
	@Autowired(required=true)
	@Qualifier(value="hibernate4AnnotatedSessionFactory")
	private SessionFactory sessionFactory;
    
    public void setSessionFactory(SessionFactory sessionFactory){
        this.sessionFactory = sessionFactory;
    }
    
	
	public List<ZcisUser> getUser() 
	{
		 @SuppressWarnings("unchecked")
		List<ZcisUser> userlist= (List<ZcisUser>) this.sessionFactory.getCurrentSession().createCriteria(ZcisUser.class).list();
		return userlist;
	}
	

}
