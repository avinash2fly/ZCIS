package com.zycus.zcis.application.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.zycus.zcis.common.api.CategoryDaoAPI;
import com.zycus.zcis.common.api.CommonDaoAPI;
import com.zycus.zcis.common.bo.Category;

@Repository
public class CategoryDaoImpl implements CategoryDaoAPI
{
	
	@Autowired(required=true)
	@Qualifier(value="hibernate4AnnotatedSessionFactory")
	private SessionFactory sessionFactory;
    
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Autowired
	private CommonDaoAPI commonDaoAPI;

	public CommonDaoAPI getCommonDaoAPI() {
		return commonDaoAPI;
	}

	public void setCommonDaoAPI(CommonDaoAPI commonDaoAPI) {
		this.commonDaoAPI = commonDaoAPI;
	}

	@Override
	public List<Category> getCategoryList(boolean isLazy) 
	{
		Criteria categoryCriteria =  this.sessionFactory.getCurrentSession().createCriteria(Category.class);
		//categoryCriteria.createAlias("postSet", "postAlias",JoinType.LEFT_OUTER_JOIN);
		//categoryCriteria.add(Restrictions.ne("postAlias.status", 4));
		categoryCriteria.addOrder(Order.asc("categoryName").ignoreCase());
		categoryCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<Category> categoryList = (List<Category>) categoryCriteria.list();
		if(!isLazy)
		{
			for(Category cat : categoryList)
			{
				cat.getPostSet().size();
			}
		}
		
			return categoryList;
	}

	@Override
	public Category getCategoryById(Long categoryId) 
	{
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(Category.class);
		criteria.add(Restrictions.eq("categoryId", categoryId));
		//criteria.createAlias("postSet", "postAlias",JoinType.LEFT_OUTER_JOIN);
		//criteria.add(Restrictions.ne("postAlias.status", 4));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		try
		{
		Category category = (Category) criteria.uniqueResult();
		return category;
		}
		catch(ObjectNotFoundException e)
		{
			return null;
		}
		
	}

	@Override
	public Category getCategoryByName(String categoryname) 
	{
		Criteria categoryNameCriteria = this.sessionFactory.getCurrentSession().createCriteria(Category.class);
		categoryNameCriteria.add(Restrictions.eq("categoryName", categoryname).ignoreCase());
		//categoryNameCriteria.createAlias("postSet", "postAlias",JoinType.LEFT_OUTER_JOIN);
		//categoryNameCriteria.add(Restrictions.ne("postAlias.status", 4));
		categoryNameCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		Category category = (Category) categoryNameCriteria.uniqueResult();
		return category;
	}

	@Override
	public void createCategory(Category category) 
	{
		commonDaoAPI.persistObject(category);
	}
}
