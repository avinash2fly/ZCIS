package com.zycus.zcis.common.util;

import java.beans.PropertyEditorSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zycus.zcis.common.api.CategoryServiceAPI;
import com.zycus.zcis.common.bo.Category;

@Component
public class CategoryEditor extends PropertyEditorSupport 
{

	@Autowired
	CategoryServiceAPI categoryServiceAPI;
	
	public CategoryServiceAPI getCategoryServiceAPI() {
		return categoryServiceAPI;
	}

	public void setCategoryServiceAPI(CategoryServiceAPI categoryServiceAPI) {
		this.categoryServiceAPI = categoryServiceAPI;
	}

	@Override
    public void setAsText(String text) 
    {
		Category category = categoryServiceAPI.getCategoryById(Long.valueOf(text),true);
		 this.setValue(category);
    }
}
