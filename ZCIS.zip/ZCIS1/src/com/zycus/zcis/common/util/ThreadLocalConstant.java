/**
 * 
 */
package com.zycus.zcis.common.util;

/**
 * @author avinash.gupta
 *
 */
public final class ThreadLocalConstant
{
   public static final ThreadLocal UserThreadLocal = new ThreadLocal();
}
