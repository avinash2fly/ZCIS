package com.zycus.zcis.common.util;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.zycus.zcis.common.bo.SessionInfo;
import com.zycus.zcis.common.bo.ZcisUser;


public class SessionListener {

	private static final Map<String, SessionInfo>	liveUsers		= new LinkedHashMap<String, SessionInfo>();
	private static final Map<String, HttpSession>	loginInUsers	= new LinkedHashMap<String, HttpSession>();

	public static void createSession(HttpServletRequest request, ZcisUser user, HttpSession session) {
		String sessionID = session.getId();

//		if (loginInUsers.containsKey(user.getEmpID().toString())) {
//			if (!liveUsers.containsKey(loginInUsers.get((user.getEmpID()).toString()).getId().toString())) {
//				destroySession(session);
//			}
//		} else {
//			loginInUsers.put(user.getEmpID().toString(), session);
//			liveUsers.put(sessionID, getSessionInfo(user, session, request));
//		}
//
//		if (!liveUsers.containsKey(loginInUsers.get(user.getEmpID().toString()).getId())) {
//			liveUsers.put(sessionID, getSessionInfo(user, session, request));
//		}
	}

	public static SessionInfo getSessionInfo(ZcisUser user, HttpSession session, HttpServletRequest request) {
		SessionInfo info = new SessionInfo();
		info.setUser(user);
		info.setLoginDate(new Date(session.getCreationTime()));
		info.setIp(request.getRemoteAddr());
		return info;
	}

	public static void destroySession(HttpSession session) {
		try {
			/*loginInUsers.remove(liveUsers.get(session.getId().toString()).getEmp().getEmpID().toString());
			liveUsers.remove(session);
			session.removeAttribute("empId");*/
			session.removeAttribute("user");
			session.invalidate();
			
		} catch (Exception e) {

		}
	}

	public static Map<String, SessionInfo> getLiveUsers() {
		return liveUsers;
	}
}