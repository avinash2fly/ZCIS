package com.zycus.zcis.common.api;

import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;

public interface CommonDaoAPI {

	void persistObject(Object obj);

	ZcisUser getUserByEmail(String emailId);

}
