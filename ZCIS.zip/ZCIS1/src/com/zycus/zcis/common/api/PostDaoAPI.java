package com.zycus.zcis.common.api;

import java.util.List;
import java.util.Set;

import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;

public interface PostDaoAPI {

	List<Post> getAllPost();

	List<Comments> getAllCommentsbyPostID(long postId);

	void saveComment(Comments comments);
	
	Post getPostById(long postId);

	long getCommentsCount(long postId);

	List<Post> getAllPostsByTitle(String searchText);

	List<Post> getAllPostsByDesc(String searchText);

	Set<Post> getAllPostsByCategory(String searchText);

}
