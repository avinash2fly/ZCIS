package com.zycus.zcis.common.api;

import java.util.List;

import com.zycus.zcis.common.bo.UserNotification;


public interface LoginDaoApi {

	void saveNotificationList(List<UserNotification> notificationList);

	void saveNotification(UserNotification notification);

	List<UserNotification> getNotificationByUserId(long userid);

	List<UserNotification> getNotificationByPostid(long postId);

	

}
