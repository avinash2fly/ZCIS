package com.zycus.zcis.common.api;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zycus.zcis.common.bo.Category;
import com.zycus.zcis.common.bo.Comments;
import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.ZcisUser;

public interface PostServiceAPI 
{

	void savePost(Post newPost);


	List<Post> getAllPost(boolean isLazy);



	List<Comments> getAllCommentsByPostID(long postId, boolean isLazy);
	
	Map<String, Object> followOrUnfollowPost(long postId, ZcisUser user);


	void persistComment(Comments comments);


	long getCommentsCount(long postId);


	Post getPostById(long postIdLong, boolean b);


	Set<Post> searchPostsByText(String searchText);

}
