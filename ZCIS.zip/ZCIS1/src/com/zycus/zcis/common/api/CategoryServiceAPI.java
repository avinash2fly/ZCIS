package com.zycus.zcis.common.api;

import java.util.List;

import com.zycus.zcis.common.bo.Category;

public interface CategoryServiceAPI 
{
	List<Category> getCategoryList(boolean isLazy);

	Category getCategoryById(Long valueOf,boolean isLazy);

	boolean createNewCategory(String categoryname);
}
