/**
 * 
 */
package com.zycus.zcis.common.api;

import java.util.List;

import com.zycus.zcis.common.bo.Post;
import com.zycus.zcis.common.bo.UserNotification;
import com.zycus.zcis.common.bo.ZcisUser;


/**
 * @author avinash.gupta
 *
 */
public interface LoginServiceApi {

	ZcisUser saveOrUpdateZcuisUser(ZcisUser zcisUser);


	void notifyUserForPost(Post post);


	List<UserNotification> getNotificationByUserId(long userid, boolean isLazy);


	void disableNotificationForPost(long postId);

	

}
