package com.zycus.zcis.common.api;

import java.util.List;

import com.zycus.zcis.common.bo.Category;

public interface CategoryDaoAPI {

	List<Category> getCategoryList(boolean isLazy);

	Category getCategoryById(Long categoryId);

	Category getCategoryByName(String categoryname);

	void createCategory(Category category);
}
