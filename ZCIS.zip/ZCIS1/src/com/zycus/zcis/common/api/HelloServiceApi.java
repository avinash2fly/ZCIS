/**
 * 
 */
package com.zycus.zcis.common.api;

import java.util.List;

import com.zycus.zcis.common.bo.ZcisUser;

/**
 * @author avinash.gupta
 *
 */
public interface HelloServiceApi {

	List<ZcisUser> getUser();

}
