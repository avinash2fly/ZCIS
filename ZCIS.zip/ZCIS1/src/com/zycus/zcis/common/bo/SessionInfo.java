package com.zycus.zcis.common.bo;

import java.io.Serializable;
import java.util.Date;

public class SessionInfo implements Serializable {

	private static final long	serialVersionUID	= 1L;
	private ZcisUser			user				= null;
	private Date				loginDate			= null;
	private String				ip					= null;



	/**
	 * @return the user
	 */
	public ZcisUser getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(ZcisUser user) {
		this.user = user;
	}

	public Date getLoginDate() {
		return loginDate;
	}

	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

}