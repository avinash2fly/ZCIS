/**
 * 
 */
package com.zycus.zcis.common.bo;

import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

/**
 * @author avinash.gupta
 *
 */

@Entity
@Table(name="ZCIS_USER_NOTIFICATION")
public class UserNotification {

	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SEQ_GEN")
	@SequenceGenerator(name="SEQ_GEN",sequenceName="ZCIS_USER_NOTIFICATION_SEQ",allocationSize=1)
	@Column(name="NOTIFICATION_ID")
	private long notificationId;
	
	
	@Column(name="NOTIFICATION_TEXT")
	private String notificationText;
	
	@Column(name="STATUS")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	boolean isViewed = false;
	
	@OneToOne
	@JoinColumn(name="USER_ID")
	ZcisUser user;
	

	@OneToOne
	@JoinColumn(name="POST_ID")
	Post post;
	
	@Column(name="NOTIFIED_DATE",insertable=false,updatable=false)
	Date date;
	
	
	/**
	 * @return the date
	 */
	public Date getDate() {
		
		long timezoneAlteredTime = date.getTime() + TimeZone.getTimeZone("Asia/Calcutta").getRawOffset();
		Date localCommentedOn = new Date(timezoneAlteredTime);
		return localCommentedOn;
		
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the notificationId
	 */
	public long getNotificationId() {
		return notificationId;
	}

	/**
	 * @param notificationId the notificationId to set
	 */
	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	/**
	 * @return the notificationText
	 */
	public String getNotificationText() {
		return this.notificationText;
	}

	/**
	 * @param notificationText the notificationText to set
	 */
	public void setNotificationText(String notificationText) {
		this.notificationText = notificationText;
	}

	/**
	 * @return the isViewed
	 */
	public boolean isViewed() {
		return isViewed;
	}

	/**
	 * @param isViewed the isViewed to set
	 */
	public void setViewed(boolean isViewed) {
		this.isViewed = isViewed;
	}

	/**
	 * @return the user
	 */
	public ZcisUser getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(ZcisUser user) {
		this.user = user;
	}

	/**
	 * @return the post
	 */
	public Post getPost() {
		return post;
	}

	/**
	 * @param post the post to set
	 */
	public void setPost(Post post) {
		this.post = post;
	}

	
}
