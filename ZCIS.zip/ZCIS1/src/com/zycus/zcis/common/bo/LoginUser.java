package com.zycus.zcis.common.bo;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

public class LoginUser {
	
	@NotBlank(message="username cannot be empty")
	@Pattern(regexp = "[a-zA-Z]+[.][a-zA-Z]+", message="please check the username")
	private String userName;
	
	@NotBlank(message="password cannot be empty")
	private String password;


	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}


	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}


	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}


	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


	
	
	

}
