/**
 * 
 */
package com.zycus.zcis.common.bo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;


/**
 * @author avinash.gupta
 *
 */
@Entity
@Table(name="ZCIS_USER")
public class ZcisUser {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SEQ_GEN")
	@SequenceGenerator(name="SEQ_GEN",sequenceName="zcis_user_seq",allocationSize=1)
	@Column(name="USER_ID")
	private 	long  		userid;
	@Column(name="USER_EMAIL")
	private 	String  	emailId;
	@Column(name="USER_FIRST_NAME")
	private 	String  	firstName;
	@Column(name="USER_LAST_NAME")
	private 	String  	lastName;
	@Column(name="USER_DISPLAY_NAME")
	private 	String  	displayName;
	@Column(name="IS_USER_ACTIVE")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private 	boolean  	isActive = true;
	@Column(name="EMPLOYEE_ID")
	private 	long		empId;
	
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "ZCIS_USER_FOLLOWING", joinColumns = { 
			@JoinColumn(name = "USER_ID", nullable = false, updatable = false) }, 
			inverseJoinColumns = { @JoinColumn(name = "FOLLOWING_USER_ID", 
					nullable = false, updatable = false) })
	private Set<ZcisUser> followingUsers;

	
	/**
	 * @return the followingUsers
	 */
	public Set<ZcisUser> getFollowingUsers() {
		return followingUsers;
	}
	/**
	 * @param followingUsers the followingUsers to set
	 */
	public void setFollowingUsers(Set<ZcisUser> followingUsers) {
		this.followingUsers = followingUsers;
	}
	/**
	 * @return the userid
	 */
	public long getUserid() {
		return userid;
	}
	/**
	 * @param userid the userid to set
	 */
	public void setUserid(long userid) {
		this.userid = userid;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}
	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the empId
	 */
	public long getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "user id : " +userid + " user name : " + emailId;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (userid ^ (userid >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ZcisUser other = (ZcisUser) obj;
		if (userid != other.userid)
			return false;
		return true;
	}

	
}
