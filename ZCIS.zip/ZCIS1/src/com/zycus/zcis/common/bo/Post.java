package com.zycus.zcis.common.bo;

import java.util.Date;
import java.util.Set;
import java.util.TimeZone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="ZCIS_POST")
public class Post 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SEQ_GEN")
	@SequenceGenerator(name="SEQ_GEN",sequenceName="zcis_post_seq",allocationSize=1)
	@Column(name="POST_ID")
	private long postId;
	
	@NotBlank(message="- Title can not be empty")
	@Column(name="TITLE")
	private String title;
	
	@NotBlank(message="- Description can not be empty")
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="CREATED_ON", insertable = false, updatable = false)
	private Date createdOn;
	
	@OneToOne
    @JoinColumn(name="POSTED_BY")
	private ZcisUser postedByUser;
	
	@Column(name="STATUS")
	private int status;
	
	@Column(name="IPADDRESS")
	private String ipAddress;
	
	 
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "ZCIS_POST_CATEORY_MAPPING", joinColumns = { 
			@JoinColumn(name = "POST_ID", nullable = false, updatable = false) }, 
			inverseJoinColumns = { @JoinColumn(name = "CATEGORY_ID", 
					nullable = false, updatable = false) })
		private Set<Category> categorySet;


	
@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
@JoinTable(name = "ZCIS_POST_FOLLOWING", joinColumns = { 
		@JoinColumn(name = "POST_ID", nullable = false, updatable = false) }, 
		inverseJoinColumns = { @JoinColumn(name = "FOLLOWER_USER_ID", 
				nullable = false, updatable = false) })
	private Set<ZcisUser> followingUserSet;


	@Column(name="IS_MAIL_REQUIRED")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean isMailRequired;
	
	@Transient
	private long noOfComments;
	
	public long getNoOfComments() {
		return noOfComments;
	}

	public void setNoOfComments(long noOfComments) {
		this.noOfComments = noOfComments;
	}

	public Post() {
		super();
	}

	public Post(long postId) {
		super();
		this.postId = postId;
	}

	public boolean getIsMailRequired() {
		return isMailRequired;
	}

	public void setIsMailRequired(boolean isMailRequired) {
		this.isMailRequired = isMailRequired;
	}

	/**
 * @return the followingUserSet
 */
public Set<ZcisUser> getFollowingUserSet() {
	return followingUserSet;
}

/**
 * @param followingUserSet the followingUserSet to set
 */
public void setFollowingUserSet(Set<ZcisUser> followingUserSet) {
	this.followingUserSet = followingUserSet;
}

	/**
	 * @return the postId
	 */
	public long getPostId() {
		return postId;
	}

	/**
	 * @param postId the postId to set
	 */
	public void setPostId(long postId) {
		this.postId = postId;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		long timezoneAlteredTime = createdOn.getTime() + TimeZone.getTimeZone("Asia/Calcutta").getRawOffset();
		Date localCommentedOn = new Date(timezoneAlteredTime);
		return localCommentedOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the postedByUser
	 */
	public ZcisUser getPostedByUser() {
		return postedByUser;
	}

	/**
	 * @param postedByUser the postedByUser to set
	 */
	public void setPostedByUser(ZcisUser postedByUser) {
		this.postedByUser = postedByUser;
	}

	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Set<Category> getCategorySet() {
		return categorySet;
	}

	public void setCategorySet(Set<Category> categorySet) {
		this.categorySet = categorySet;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (postId ^ (postId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Post other = (Post) obj;
		if (postId != other.postId)
			return false;
		return true;
	}
	
	
}
