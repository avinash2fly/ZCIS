package com.zycus.zcis.common.bo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ZCIS_CATEGORY")
public class Category {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SEQ_GEN")
	@SequenceGenerator(name="SEQ_GEN",sequenceName="zcis_category_seq",allocationSize=1)
	@Column(name="CATEGORY_ID")
	private long categoryId;

	@Column(name="CATEGORY_NAME")
	private String categoryName;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "ZCIS_POST_CATEORY_MAPPING", joinColumns = { 
			@JoinColumn(name = "CATEGORY_ID", nullable = false, updatable = false) }, 
			inverseJoinColumns = { @JoinColumn(name = "POST_ID", 
					nullable = false, updatable = false) })
		private Set<Post> postSet;

	
	
	public Set<Post> getPostSet() {
		return postSet;
	}

	public void setPostSet(Set<Post> postSet) {
		this.postSet = postSet;
	}

	/**
	 * @return the categoryId
	 */
	public long getCategoryId() {
		return categoryId;
	}

	/**
	 * @param categoryId the categoryId to set
	 */
	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}

	/**
	 * @param categoryName the categoryName to set
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
}
