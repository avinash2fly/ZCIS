package com.zycus.zcis.common.bo;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ZCIS_COMMENTS")
public class Comments 
{

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SEQ_GEN")
	@SequenceGenerator(name="SEQ_GEN",sequenceName="ZCIS_COMMENTS_SEQ",allocationSize=1)
	@Column(name="COMMENT_ID")
	private long commentId;
	
	@Column(name="COMMENT_TEXT")
	private String commentText;

	@OneToOne
    @JoinColumn(name="COMMENTED_BY")
	private ZcisUser commentedBy;
	
	@Column(name="COMMENTED_ON", insertable = false, updatable = false)
	private Date commentedOn;
	
	@ManyToOne
    @JoinColumn(name="POST_ID")
	private Post post;
	
	@Column(name="IPADDRESS")
	private String ipAddress;

	/**
	 * @return the commentId
	 */
	public long getCommentId() {
		return commentId;
	}

	/**
	 * @param commentId the commentId to set
	 */
	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}

	/**
	 * @return the commentText
	 */
	public String getCommentText() {
		return commentText;
	}

	/**
	 * @param commentText the commentText to set
	 */
	public void setCommentText(String commentText) {
		this.commentText = commentText;
	}

	/**
	 * @return the commentedBy
	 */
	public ZcisUser getCommentedBy() {
		return commentedBy;
	}

	/**
	 * @param commentedBy the commentedBy to set
	 */
	public void setCommentedBy(ZcisUser commentedBy) {
		this.commentedBy = commentedBy;
	}

	/**
	 * @return the commentedOn
	 */
	public Date getCommentedOn() {
		
		
		long timezoneAlteredTime = commentedOn.getTime() + TimeZone.getTimeZone("Asia/Calcutta").getRawOffset();
		Date localCommentedOn = new Date(timezoneAlteredTime);
		return localCommentedOn;
	}

	/**
	 * @param commentedOn the commentedOn to set
	 */
	public void setCommentedOn(Date commentedOn) {
		this.commentedOn = commentedOn;
	}

	/**
	 * @return the post
	 */
	public Post getPost() {
		return post;
	}

	/**
	 * @param post the post to set
	 */
	public void setPost(Post post) {
		this.post = post;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	
}
