$(document).ready(function(){
	var d = $("#comments-box");
	d.scrollTop(d.prop("scrollHeight"));
                $(".transparentDiv").on("click",function(){
                                $(".transparentDiv").hide();
                                $(".loginFormDiv").hide();
                });

                showCategoryList();

                	$("#categorySetId").multiselect({
                		 selectedList: 3
                			}).multiselectfilter();
                	doPollNotification();
                	$("[class^=divPage]").hide();
                	$(".divPage"+1).show();
                	$("[id^=postPage]").removeClass("activePage");
                	$("#postPage"+1).addClass("activePage");
                	//$("#div1").animate({ scrollTop: $('#div1').prop("scrollHeight")}, 1000); --to  bring scrollbar down
                	/*$.cookie('animations','bounce');
                    $('#change-transitions button').click(function() {
                        $("body").removeClass($.cookie('animations'));
                        var ani = $(this).attr('data-value');
                        $("body").addClass("animated " + ani);
                        $.cookie('animations', ani);
                    });*/
                	
});



function doPollNotification(){
        getNotificationCount();
        setTimeout(doPollNotification,5000);
}



function showLoginForm(){
                
	jQuery.ajax({
		  type: 'POST',
		  url: strContextPath + '/almac/loginForm.do',
		  //data: udata,
		  dataType: "text",
		  success :  function(data){ 
			$('#loginFormOuterDiv').html(data)
			  $(".transparentDiv").show();
            $(".loginFormDiv").show();
			
		  }
	});
                
                
}


function submitLoginForm(){
	var url= strContextPath + '/almac/performLogin.do';
	jQuery.ajax({
		  type: 'POST',
		  url: url,
		  data: $('#loginForm').serialize(),
		  dataType: "text",
		  success :  function(data){
			  if(data)
			  {
				  $('#loginFormOuterDiv').html(data)
				  $(".transparentDiv").show();
				  $(".loginFormDiv").show();
			  }
			  else
			  {
				  location.reload();
			  }
			
		  }
	});
	//$.post(url, $('#loginForm').serialize());
	
                
}



function closeLogin(){
                $(".transparentDiv").hide();
                $(".loginFormDiv").hide();
}

function login(){
                $("#user-not-logged-in").hide();
                $("#user-logged-in").show();
                $("#login-box").hide();
                $("#zcis-chat-box").show();
                $("#user-logged-in h4").text($("#inputName").val());
                closeLogin();
}

function logoutUser(){
	var url= strContextPath + '/alc/logout.do';
	jQuery.ajax({
		  type: 'POST',
		  url: url,
		  dataType: "json",
		  success :  function(data){
			  if(data.success)
			  {
				  location.reload();
				  
			  }
			  else
			  {
				  
			  }
			
		  }
	});
}


function showCategoryList()
{

	jQuery.ajax({
		  type: 'GET',
		  url: strContextPath + '/acmac/getCategoryList.do',
		  //data: udata,
		  dataType: "text",
		  success :  function(data){ 
						$('#category-list-id').html(data);
			  		  }});
}

function createCategory()
{
	var param= $('#new-category-name').val();
	jQuery.ajax({
		  type: 'GET',
		  url: strContextPath + '/acmac/createNewCategory.do',
		  data: {categoryname : param},
		  dataType: "json",
		  success :  function(data)
		  			{ 
			  
			  			if(data.success)
			  				{
			  					location.reload();
			  				}
			  			else
			  				{
			  					alert("Category with name "+param+" already exists!");
			  				}
				
		  			}
		  });
}

function search()
{
	var searchText = $('#searchText').val();
	if(!searchText||searchText.length<3)
		{
			return;
		}
	
	$('#searchFormId').submit();	
}

function displayButton()
{
	var searchText = $('#searchText').val();
	if(!searchText||searchText.length<3)
	{
		$('#searchButttonId').hide();
		return;
	}
	else
		$('#searchButttonId').show();
	}
	
function showHideNotification()
{
	var isActive = $('#notificationPopup').hasClass("activeNotify");
	if(isActive)
	{
		$('#notificationPopup').removeClass("activeNotify");
		$('#notificationPopup').hide();
	}
	else
	{
		jQuery.ajax({
			  type: 'POST',
			  url: strContextPath + '/almac/showNotification.do',
			  data: {},
			  dataType: "text",
			  success :  function(data)
			  			{ 
				  			$('#notificationPopup').html(data);
				  			$('#notificationPopup').addClass("activeNotify");
				  			$('#notificationPopup').show();
			  			}
			  });
	}
}

function getNotificationCount()
{
		jQuery.ajax({
			  type: 'POST',
			  url: strContextPath + '/almac/getNotificationCount.do',
			  data: {},
			  dataType: "json",
			  success :  function(data)
			  			{ 
				  			if(data.success)
				  				{
				  					$('#notificationCount').text(data.count);
				  				}
			  			}
			  });
	
}

function showPage(index)
{
	$("[class^=divPage]").hide();
	$(".divPage"+index).show();
	$("[id^=postPage]").removeClass("activePage");
	$("#postPage"+index).addClass("activePage");
}