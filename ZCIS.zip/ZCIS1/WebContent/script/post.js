function postComment(){
		var url= strContextPath + '/aPost/postComment.do';
		var commentText = $('#commentArea').val();
		var postId = $("#commentPostId").val();
		var param = {	
						commentText : commentText,
						postId : postId
					}
		jQuery.ajax({
			  type: 'POST',
			  url: url,
			  data: param,
			  dataType: "text",
			  success :  function(data){
				  $('#commentsBox').html(data);
				  $('#commentArea').val("");
				
			  }
		});           
	}

function followOrUnfollowPost()
{
	var url = strContextPath + '/acmac/followOrUnfollowPost.do';
	var postId = $('#commentPostId').val();
	jQuery.ajax({
		  type: 'POST',
		  url: url,
		  data : {postId:postId},
		  dataType: "json",
		  success :  function(data){
			  if(data.following)
			  {
				$('#followBtnId').html('Unfollow');
				$('#followBtnId').removeClass("btn-info");
				$('#followBtnId').addClass("btn-default");	
			  }	  
			  else
			  {
				  $('#followBtnId').html('Follow');
				  $('#followBtnId').removeClass("btn-default");
				  $('#followBtnId').addClass("btn-info");	
			  }
			  $('#followingNoSpanId').html(data.noOfFollowers);
			
		  }
	});  
}

